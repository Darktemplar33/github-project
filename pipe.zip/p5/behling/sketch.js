function setup() {
  createCanvas(400, 400);
  angleMode(degrees);
  colorMode(RGB,255,255,255);
  let p=7;
print("the number of pipes are "+p);
}

function draw() {
  background(220);
  push();
   for(x=0;x<width;x+=125){
  scale(1,1.2);
  down_pipes(x,0);
   }
  pop();
  push();
  rotate(1);
  pipes(200,10);
  pop();
  for(x=0;x<width;x+=125){
    pipes(x,200);
  }
fill(224,150,150);
  rect(0,375,400,25);
}
function pipes(x,y){
  push();
  translate(x,y);
  fill(0,255,0);
  rect(75,100,40,100);
  fill(0);
  ellipse(95,100,40,10);
  pop();
}
function down_pipes(x,y){
 push();
  translate(x,y);
  fill(0,255,0);
  rect(75,0,40,100);
  fill(0);
  ellipse(95,100,40,10);
  pop();
}