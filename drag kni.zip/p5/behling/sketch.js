var drag;
var kni;
var smo;
function preload(){
  drag=loadImage("drag.jpg");
  kni=loadImage("knight.jpg");
  smo=loadImage("clouds.png");
}

function setup() {
  createCanvas(400, 400);
  textFont("Arial")
}

function draw() {
  background(200)
  image(drag,0,0,400,400)
  image(kni,mouseX,mouseY,100,100);
  image(smo,0,300)
  textSize(32);
  text("beware of the dragon",0,100);
  push()
  textFont("Syne Tactile")
  fill(200,50,50);
  stroke(10);
  text("but also beware the knight",0,150,200,300);
  pop()
}