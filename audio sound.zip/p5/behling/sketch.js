
var amp
var sine
var ping
var mic
var freg=200
var capture
function preload(){
  ping=loadSound("Ping.wav")
}

function setup() {
  let cnv = createCanvas(400, 400);
  cnv.mousePressed(userStartAudio);
  	mic = new p5.AudioIn();
	mic.start();

	amp = new p5.Amplitude();
	amp.setInput(mic);

sine = new p5.SinOsc();
	sine.start();

	capture = createCapture();
	capture.hide();
}

function draw() {
  background(220);
	image(capture, 0, 0, width, height);
	filter(INVERT);

   micLevel = mic.getLevel();
  let y = height/2 - micLevel*2 * height/2;
  ellipse(100, 350, y, y);
  ellipse(200,350,y,y)
  ellipse(300,350,y,y)
  rect(150,150,50,50)


  if(mouseX>150 && mouseX<200 && mouseY>150 && mouseY<200)
  	ping.play()

	var hertz = map(mouseX, 0, width, 20.0, 440.0);

	sine.freq(hertz);

	stroke(204);

	for (var x = 0; x < width; x++) {

		var angle = map(x, 0, width, 0, TWO_PI * hertz);

		var sinValue = sin(angle) * 200;

		line(x, 0, x, height/2 + sinValue);
		
	}
  }